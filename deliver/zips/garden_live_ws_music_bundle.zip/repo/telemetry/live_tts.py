from __future__ import annotations

import math
import os
import struct
import subprocess
import tempfile
import threading
import time
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

VoiceSource = Literal["mic", "idle"]
AiSource = Literal["idle", "macos_say", "silent", "presence_echo"]

_VOICE_TTL_SEC = 2.5
_SPEAK_COOLDOWN_SEC = 4.0
_VOICE_TRIGGER_AMP = 0.14
# Daniel (UK male) — never fall back to legacy Samantha / novelty voices.
_VOICE_CANDIDATES = ("Daniel",)
_TTS_RATE = int(os.environ.get("GARDEN_TTS_RATE", "155"))
_TTS_ENABLED = os.environ.get("GARDEN_TTS_ENABLED", "1").strip().lower() not in (
    "0",
    "false",
    "off",
    "no",
)
_AUTO_SPEAK_ON_MIC = os.environ.get("GARDEN_TTS_AUTO_ON_MIC", "0").strip().lower() in (
    "1",
    "true",
    "on",
    "yes",
)
_RESOLVED_VOICE: str | None = None
_VOICE_LOCK = threading.Lock()


@dataclass
class VoiceState:
    voice_freq: float = 0.0
    voice_amp: float = 0.0
    updated_at: float = 0.0
    source: VoiceSource = "idle"


@dataclass
class AiFrame:
    t: float
    freq: float
    amp: float


@dataclass
class GardenLiveState:
    voice: VoiceState = field(default_factory=VoiceState)
    ai_frames: list[AiFrame] = field(default_factory=list)
    ai_started_at: float = 0.0
    ai_duration: float = 0.0
    ai_source: AiSource = "idle"
    ai_text: str = ""
    speaking: bool = False
    last_speak_at: float = 0.0
    last_latency_ms: float = 18.0
    presence_enabled: bool = False
    lock: threading.Lock = field(default_factory=threading.Lock)


STATE = GardenLiveState()


def tts_status() -> dict[str, str | bool]:
    voice = _resolve_voice()
    return {
        "backend": "macos_tts" if _TTS_ENABLED and voice else "silent",
        "tts_enabled": bool(_TTS_ENABLED and voice),
        "tts_voice": voice or "",
        "llm_stream": "disabled",
        "auto_speak_on_mic": _AUTO_SPEAK_ON_MIC,
        "presence_enabled": STATE.presence_enabled,
    }


def set_presence(enabled: bool) -> dict[str, bool]:
    with STATE.lock:
        STATE.presence_enabled = bool(enabled)
        return {"enabled": STATE.presence_enabled}


def _voice_installed(name: str) -> bool:
    try:
        proc = subprocess.run(
            ["say", "-v", name, "ok"],
            capture_output=True,
            timeout=4,
            check=False,
        )
        return proc.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def _resolve_voice() -> str | None:
    global _RESOLVED_VOICE
    if not _TTS_ENABLED:
        return None
    with _VOICE_LOCK:
        if _RESOLVED_VOICE is not None:
            return _RESOLVED_VOICE or None
        preferred = os.environ.get("GARDEN_TTS_VOICE", "").strip()
        if preferred and _voice_installed(preferred):
            _RESOLVED_VOICE = preferred
            return preferred
        for candidate in _VOICE_CANDIDATES:
            if _voice_installed(candidate):
                _RESOLVED_VOICE = candidate
                return candidate
        _RESOLVED_VOICE = ""
        return None


def _voice_snapshot(now: float) -> tuple[float, VoiceSource]:
    age = now - STATE.voice.updated_at
    if age <= _VOICE_TTL_SEC and STATE.voice.voice_freq > 30:
        return STATE.voice.voice_freq, "mic"
    return 0.0, "idle"


def _ai_snapshot(now: float) -> tuple[float, float, AiSource]:
    if not STATE.speaking or not STATE.ai_frames:
        return 0.0, 0.0, "idle"
    elapsed = max(0.0, now - STATE.ai_started_at)
    if elapsed > STATE.ai_duration:
        return STATE.ai_frames[-1].freq, 0.06, "macos_say"
    frame = STATE.ai_frames[0]
    for item in STATE.ai_frames:
        if item.t <= elapsed:
            frame = item
        else:
            break
    return frame.freq, frame.amp, "macos_say"


def report_voice(voice_freq: float, voice_amp: float) -> None:
    now = time.time()
    with STATE.lock:
        STATE.voice.voice_freq = float(voice_freq)
        STATE.voice.voice_amp = float(voice_amp)
        STATE.voice.updated_at = now
        STATE.voice.source = "mic"
        if (
            _AUTO_SPEAK_ON_MIC
            and _TTS_ENABLED
            and _resolve_voice()
            and voice_amp >= _VOICE_TRIGGER_AMP
            and not STATE.speaking
            and (now - STATE.last_speak_at) >= _SPEAK_COOLDOWN_SEC
        ):
            threading.Thread(
                target=_speak_worker,
                args=(_build_reply(voice_freq),),
                daemon=True,
            ).start()


def speak_now(text: str | None = None) -> dict[str, str]:
    if not (text or "").strip():
        return {"status": "noop", "text": ""}
    now = time.time()
    voice = _resolve_voice()
    if not _TTS_ENABLED or not voice:
        return {"status": "disabled", "text": "", "reason": "tts_off_or_no_voice"}
    with STATE.lock:
        if STATE.speaking:
            return {"status": "busy", "text": STATE.ai_text}
        if (now - STATE.last_speak_at) < 1.0:
            return {"status": "cooldown", "text": ""}
        reply = text.strip()
    threading.Thread(target=_speak_worker, args=(reply,), daemon=True).start()
    return {"status": "queued", "text": reply, "voice": voice}


def telemetry_payload() -> dict[str, float | str | bool]:
    now = time.time()
    with STATE.lock:
        if STATE.speaking and STATE.ai_duration > 0 and (now - STATE.ai_started_at) > STATE.ai_duration + 0.2:
            STATE.speaking = False
            STATE.ai_source = "idle"
        voice_freq, voice_source = _voice_snapshot(now)
        ai_freq, ai_amp, ai_source = _ai_snapshot(now)
        if (
            ai_source == "idle"
            and STATE.presence_enabled
            and voice_source == "mic"
            and voice_freq > 30
        ):
            ai_freq = voice_freq
            ai_amp = min(1.0, max(0.03, STATE.voice.voice_amp * 0.75))
            ai_source = "presence_echo"
        latency = STATE.last_latency_ms
        speaking = STATE.speaking
        ai_text = STATE.ai_text
        presence_on = STATE.presence_enabled
    active = voice_source == "mic" or ai_source != "idle" or speaking
    return {
        "t": now,
        "mode": "macos_tts" if _TTS_ENABLED and _resolve_voice() else "silent",
        "voiceSource": voice_source,
        "voiceFreq": voice_freq,
        "aiSource": ai_source,
        "aiFreq": ai_freq,
        "aiAmplitude": ai_amp,
        "latencyMs": latency if active else 0.0,
        "speaking": speaking,
        "aiText": ai_text,
        "ttsVoice": _resolve_voice() or "",
        "llmDialogue": False,
        "active": active,
        "presenceEnabled": presence_on,
    }


def _build_reply(voice_freq: float) -> str:
    # v1: one short presence line — no LLM dialogue yet.
    _ = voice_freq
    return "I'm here."


def _analyze_wav(path: Path) -> tuple[list[AiFrame], float]:
    with wave.open(str(path), "rb") as wf:
        channels = wf.getnchannels()
        sample_rate = wf.getframerate()
        sample_width = wf.getsampwidth()
        frames = wf.readframes(wf.getnframes())

    if channels > 1:
        frames = _to_mono(frames, sample_width, channels)

    if sample_width != 2:
        frames = _convert_width(frames, sample_width, 2)
        sample_width = 2

    total_samples = len(frames) // sample_width
    duration = total_samples / max(1, sample_rate)
    window = max(512, sample_rate // 20)
    hop = max(256, window // 2)
    out: list[AiFrame] = []

    for start in range(0, max(1, total_samples - window), hop):
        chunk = frames[start * sample_width : (start + window) * sample_width]
        if len(chunk) < window * sample_width:
            break
        rms = _rms(chunk, sample_width) / 32768.0
        amp = min(1.0, max(0.03, rms * 2.4))
        freq = _dominant_freq(chunk, sample_rate)
        out.append(AiFrame(t=start / sample_rate, freq=freq, amp=amp))

    if not out:
        out = [AiFrame(t=0.0, freq=220.0, amp=0.12)]
    return out, duration


def _to_mono(frames: bytes, sample_width: int, channels: int) -> bytes:
    if channels == 1:
        return frames
    out = bytearray()
    step = sample_width * channels
    for i in range(0, len(frames), step):
        chunk = frames[i : i + step]
        if len(chunk) < step:
            break
        total = 0
        for ch in range(channels):
            start = ch * sample_width
            total += _read_sample(chunk[start : start + sample_width], sample_width)
        avg = int(total / channels)
        out.extend(_write_sample(avg, sample_width))
    return bytes(out)


def _convert_width(frames: bytes, from_width: int, to_width: int) -> bytes:
    if from_width == to_width:
        return frames
    out = bytearray()
    for i in range(0, len(frames), from_width):
        sample = _read_sample(frames[i : i + from_width], from_width)
        out.extend(_write_sample(sample, to_width))
    return bytes(out)


def _read_sample(data: bytes, sample_width: int) -> int:
    if sample_width == 1:
        return data[0] - 128
    if sample_width == 2:
        return struct.unpack("<h", data)[0]
    if sample_width == 4:
        return int(struct.unpack("<i", data)[0] / 65536)
    return 0


def _write_sample(value: int, sample_width: int) -> bytes:
    if sample_width == 1:
        return bytes([max(0, min(255, value + 128))])
    if sample_width == 2:
        return struct.pack("<h", max(-32768, min(32767, value)))
    if sample_width == 4:
        return struct.pack("<i", max(-2147483648, min(2147483647, value * 65536)))
    return b"\x00\x00"


def _rms(chunk: bytes, sample_width: int) -> float:
    if not chunk:
        return 0.0
    total = 0.0
    count = 0
    for i in range(0, len(chunk), sample_width):
        sample = _read_sample(chunk[i : i + sample_width], sample_width)
        total += sample * sample
        count += 1
    if count == 0:
        return 0.0
    return math.sqrt(total / count)


def _dominant_freq(chunk: bytes, sample_rate: int) -> float:
    crossing = 0
    prev = 0
    for i in range(0, len(chunk) - 1, 2):
        sample = int.from_bytes(chunk[i : i + 2], "little", signed=True)
        if prev <= 0 < sample or prev >= 0 > sample:
            crossing += 1
        prev = sample
    seconds = (len(chunk) / 2) / max(1, sample_rate)
    if seconds <= 0 or crossing < 2:
        return 220.0
    freq = crossing / (2 * seconds)
    return float(max(90.0, min(900.0, freq)))


def _speak_worker(text: str) -> None:
    voice = _resolve_voice()
    if not voice:
        return
    started = time.perf_counter()
    tmp = Path(tempfile.mkdtemp(prefix="garden_tts_"))
    aiff = tmp / "reply.aiff"
    wav = tmp / "reply.wav"
    try:
        subprocess.run(
            ["say", "-v", voice, "-r", str(_TTS_RATE), "-o", str(aiff), text],
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["afconvert", "-f", "WAVE", "-d", "LEI16", str(aiff), str(wav)],
            check=True,
            capture_output=True,
        )
        frames, duration = _analyze_wav(wav)
        now = time.time()
        with STATE.lock:
            STATE.ai_frames = frames
            STATE.ai_duration = duration
            STATE.ai_started_at = now
            STATE.ai_text = text
            STATE.ai_source = "macos_say"
            STATE.speaking = True
            STATE.last_speak_at = now
            STATE.last_latency_ms = max(8.0, (time.perf_counter() - started) * 1000.0)
        subprocess.run(["afplay", str(aiff)], check=False, capture_output=True)
    except (subprocess.CalledProcessError, OSError, wave.Error):
        with STATE.lock:
            STATE.speaking = False
            STATE.ai_source = "idle"
    finally:
        with STATE.lock:
            if STATE.speaking:
                STATE.speaking = False
                STATE.ai_source = "idle"
        for path in (aiff, wav):
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
        try:
            tmp.rmdir()
        except OSError:
            pass
