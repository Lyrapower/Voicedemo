from __future__ import annotations

import sys
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .live_tts import report_voice, set_presence, speak_now, telemetry_payload

_ROOT = Path(__file__).resolve().parents[2]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from scripts.garden_services import (  # noqa: E402
    compiled_memory_payload,
    music_catalog,
    resolve_music_file,
    run_memory_compile,
)

router = APIRouter(tags=["garden"])


class VoiceReport(BaseModel):
    voiceFreq: float = Field(ge=0, le=20000)
    voiceAmp: float = Field(ge=0, le=1, default=0.0)


class SpeakRequest(BaseModel):
    text: str | None = None


class PresenceRequest(BaseModel):
    enabled: bool


@router.get("/api/telemetry")
async def telemetry() -> dict[str, float | str | bool]:
    return telemetry_payload()


@router.post("/api/voice")
async def voice(body: VoiceReport) -> dict[str, str]:
    report_voice(body.voiceFreq, body.voiceAmp)
    return {"status": "ok", "source": "mic"}


@router.post("/api/presence")
async def presence(body: PresenceRequest) -> dict[str, bool]:
    return set_presence(body.enabled)


@router.post("/api/speak")
async def speak(body: SpeakRequest | None = None) -> dict[str, str]:
    text = body.text if body else None
    return speak_now(text)


@router.get("/api/memory/compiled")
async def memory_compiled() -> dict:
    """Entry B (8787): Grid compile — sovereign on particle router, not proxied to 8500."""
    return compiled_memory_payload()


@router.post("/api/memory/compile")
async def memory_compile() -> dict:
    return run_memory_compile()


@router.get("/api/music/catalog")
async def music_list() -> dict:
    return music_catalog()


@router.get("/assets/music/{filename}")
async def music_asset(filename: str) -> FileResponse:
    path = resolve_music_file(filename)
    if path is None:
        raise HTTPException(status_code=404, detail="track not found")
    return FileResponse(path)
