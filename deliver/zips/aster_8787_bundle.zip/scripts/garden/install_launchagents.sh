#!/usr/bin/env bash
# Install Garden stack LaunchAgents (5173 fallback + 8788 telemetry + 8787 Aster).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
SRC="${ROOT}/scripts/garden/launchd"
DEST="${HOME}/Library/LaunchAgents"
LOG_DIR="${HOME}/Library/Logs/demo-garden"
UID_NUM="$(id -u)"
DOMAIN="gui/${UID_NUM}"

PYTHON="/Library/Frameworks/Python.framework/Versions/3.13/bin/python3"
if [[ ! -x "${PYTHON}" ]]; then
  PYTHON="$(command -v python3)"
fi
UVICORN="/Library/Frameworks/Python.framework/Versions/3.13/bin/uvicorn"
if [[ ! -x "${UVICORN}" ]]; then
  UVICORN="$(command -v uvicorn)"
fi

AGENTS=(
  com.demo.garden.fallback5173
  com.demo.garden.telemetry8788
  com.demo.garden.aster8787
)
PORTS=(5173 8788 8787)

mkdir -p "${DEST}" "${LOG_DIR}"
chmod +x "${ROOT}/scripts/garden/start_aster_8787.sh" "${ROOT}/scripts/garden/start_aster_8787.py"

stop_port_listeners() {
  local port=$1
  if ! command -v lsof >/dev/null 2>&1; then
    return 0
  fi
  local pids
  pids="$(lsof -tiTCP:"${port}" -sTCP:LISTEN 2>/dev/null || true)"
  if [[ -n "${pids}" ]]; then
    echo "Stopping stale listener(s) on :${port} (${pids})"
    kill ${pids} 2>/dev/null || true
    sleep 1
  fi
}

render_plist() {
  local src_file=$1 dest_file=$2
  sed \
    -e "s|__HOME__|${HOME}|g" \
    -e "s|__DEMO_ROOT__|${ROOT}|g" \
    -e "s|__PYTHON__|${PYTHON}|g" \
    -e "s|__UVICORN__|${UVICORN}|g" \
    "${src_file}" > "${dest_file}"
}

bootout_if_loaded() {
  local label=$1
  local dest_file="${DEST}/${label}.plist"
  if launchctl print "${DOMAIN}/${label}" >/dev/null 2>&1; then
    launchctl bootout "${DOMAIN}" "${dest_file}" 2>/dev/null || true
  fi
}

echo "Installing Garden LaunchAgents to ${DEST}"
for label in "${AGENTS[@]}"; do
  bootout_if_loaded "${label}"
done
for port in "${PORTS[@]}"; do
  stop_port_listeners "${port}"
done
for label in "${AGENTS[@]}"; do
  render_plist "${SRC}/${label}.plist" "${DEST}/${label}.plist"
done

echo "Loading agents (5173 → 8788 → 8787)..."
for label in "${AGENTS[@]}"; do
  launchctl bootstrap "${DOMAIN}" "${DEST}/${label}.plist"
  launchctl enable "${DOMAIN}/${label}"
  launchctl kickstart -k "${DOMAIN}/${label}" || true
done

sleep 3
echo
echo "Port check:"
for port in 5173 8788 8787; do
  if lsof -iTCP:"${port}" -sTCP:LISTEN >/dev/null 2>&1; then
    echo "  :${port} listening"
  else
    echo "  :${port} NOT listening (see ${LOG_DIR})"
  fi
done

echo
echo "Open: http://127.0.0.1:8787/"
echo "Logs: ${LOG_DIR}/"
