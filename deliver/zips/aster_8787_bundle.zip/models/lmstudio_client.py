"""LM Studio OpenAI-compatible API — local inference (no Ollama)."""

from __future__ import annotations

import json
import logging
import os
from typing import Any, AsyncIterator, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


def _defaults_from_aster() -> tuple[str, str, float, int]:
    try:
        from .aster_config import (
            lm_studio_api_model,
            lm_studio_base,
            lm_studio_max_tokens,
            lm_studio_temperature,
        )

        return (
            lm_studio_base().rstrip("/"),
            lm_studio_api_model(),
            lm_studio_temperature(),
            lm_studio_max_tokens(),
        )
    except Exception:
        return "http://127.0.0.1:1234/v1", "qwen2.5-1.5b", 0.3, 512


_ASTER_BASE, _ASTER_MODEL, _ASTER_TEMP, _ASTER_MAX_TOKENS = _defaults_from_aster()

DEFAULT_BASE = os.environ.get("LM_STUDIO_BASE_URL", _ASTER_BASE).rstrip("/")
DEFAULT_MODEL = os.environ.get("LM_STUDIO_MODEL", _ASTER_MODEL)
DEFAULT_TEMPERATURE = float(os.environ.get("LLM_TEMPERATURE", str(_ASTER_TEMP)))
DEFAULT_MAX_TOKENS = int(os.environ.get("LLM_NUM_PREDICT", str(_ASTER_MAX_TOKENS)))


def _auth_headers() -> Dict[str, str]:
    """LM Studio local server auth — env override or ~/.lmstudio/.internal/lms-key-2."""
    headers: Dict[str, str] = {"Content-Type": "application/json"}
    key = ""
    try:
        import sys
        from pathlib import Path

        eni_echo = (
            Path(__file__).resolve().parents[1]
            / "echo_nodes_interface"
            / "incoming"
            / "echo_nodes"
        )
        if eni_echo.is_dir() and str(eni_echo) not in sys.path:
            sys.path.insert(0, str(eni_echo))
        from lm_studio_auth import resolve_lmstudio_api_key

        key = resolve_lmstudio_api_key()
    except Exception:
        key = (
            os.environ.get("LM_API_TOKEN")
            or os.environ.get("LM_STUDIO_API_KEY")
            or os.environ.get("LMSTUDIO_API_KEY")
            or ""
        ).strip()
    if key:
        headers["Authorization"] = f"Bearer {key}"
    return headers


def server_reachable(base_url: str | None = None, timeout: float = 5.0) -> bool:
    """True if LM Studio local server responds (200 or 401 = up)."""
    base = (base_url or DEFAULT_BASE).rstrip("/")
    try:
        r = requests.get(f"{base}/models", headers=_auth_headers(), timeout=timeout)
        return r.status_code in (200, 401)
    except Exception:
        return False


def list_models(base_url: str | None = None, timeout: float = 5.0) -> List[str]:
    base = (base_url or DEFAULT_BASE).rstrip("/")
    try:
        r = requests.get(f"{base}/models", headers=_auth_headers(), timeout=timeout)
        if r.status_code == 401 and not _auth_headers().get("Authorization"):
            return [DEFAULT_MODEL]
        r.raise_for_status()
        data = r.json().get("data") or []
        return [str(m.get("id", "")) for m in data if m.get("id")]
    except Exception as e:
        logger.warning("LM Studio models list failed: %s", e)
        return []


def model_available(model: str, base_url: str | None = None) -> bool:
    base = (base_url or DEFAULT_BASE).rstrip("/")
    if not server_reachable(base):
        return False
    models = list_models(base)
    if not models:
        return server_reachable(base)
    if model in models:
        return True
    ml = model.lower()
    for m in models:
        if "9b" in m.lower() or "3.5-9" in m.lower():
            continue
        if ml in m.lower() or m.lower() in ml:
            return True
        if "1.5" in ml and "1.5" in m.lower() and "instruct" in ml and "instruct" in m.lower():
            return True
    return False


def chat_completion(
    messages: List[Dict[str, str]],
    *,
    model: str | None = None,
    base_url: str | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
    timeout: float = 300.0,
) -> Dict[str, Any]:
    base = (base_url or DEFAULT_BASE).rstrip("/")
    model = model or DEFAULT_MODEL
    temperature = DEFAULT_TEMPERATURE if temperature is None else temperature
    max_tokens = DEFAULT_MAX_TOKENS if max_tokens is None else max_tokens
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
    }
    r = requests.post(
        f"{base}/chat/completions",
        json=payload,
        headers=_auth_headers(),
        timeout=timeout,
    )
    r.raise_for_status()
    body = r.json()
    choices = body.get("choices") or []
    if not choices:
        return {"error": "LM Studio returned no choices"}
    content = (choices[0].get("message") or {}).get("content") or ""
    usage = body.get("usage") or {}
    return {
        "response": str(content).strip(),
        "eval_count": usage.get("completion_tokens", 0),
        "total_duration_ns": 0,
        "lm_studio_model": model,
    }


async def stream_chat(
    messages: List[Dict[str, Any]],
    *,
    model: str | None = None,
    base_url: str | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
    timeout: float = 300.0,
) -> AsyncIterator[str]:
    import asyncio

    base = (base_url or DEFAULT_BASE).rstrip("/")
    model = model or DEFAULT_MODEL
    temperature = DEFAULT_TEMPERATURE if temperature is None else temperature
    max_tokens = DEFAULT_MAX_TOKENS if max_tokens is None else max_tokens
    queue: asyncio.Queue[str | None] = asyncio.Queue()

    def _worker() -> None:
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
        }
        try:
            with requests.post(
                f"{base}/chat/completions",
                json=payload,
                headers=_auth_headers(),
                stream=True,
                timeout=timeout,
            ) as resp:
                resp.raise_for_status()
                for raw_line in resp.iter_lines(decode_unicode=True):
                    if not raw_line or not raw_line.startswith("data:"):
                        continue
                    data = raw_line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                    except json.JSONDecodeError:
                        continue
                    delta = (chunk.get("choices") or [{}])[0].get("delta") or {}
                    content = delta.get("content") or ""
                    if content:
                        queue.put_nowait(content)
        except Exception as e:
            logger.error("LM Studio stream error: %s", e)
        finally:
            queue.put_nowait(None)

    loop = asyncio.get_event_loop()
    loop.run_in_executor(None, _worker)
    while True:
        item = await queue.get()
        if item is None:
            break
        yield item
