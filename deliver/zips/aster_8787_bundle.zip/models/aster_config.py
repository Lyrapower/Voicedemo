"""Load active Aster config from config/aster.toml."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

_REPO_ROOT = Path(__file__).resolve().parents[1]
_CONFIG_PATH = _REPO_ROOT / "config" / "aster.toml"


def _parse_toml(text: str) -> dict[str, Any]:
    try:
        import tomllib

        return tomllib.loads(text)
    except ImportError:
        import tomli

        return tomli.loads(text)


@lru_cache(maxsize=1)
def load_aster_config() -> dict[str, Any]:
    if not _CONFIG_PATH.is_file():
        return {}
    return _parse_toml(_CONFIG_PATH.read_text(encoding="utf-8"))


def repo_root() -> Path:
    return _REPO_ROOT


def section(name: str) -> dict[str, Any]:
    val = load_aster_config().get(name, {})
    return val if isinstance(val, dict) else {}


def lm_studio_api_model() -> str:
    ls = section("lm_studio")
    return str(ls.get("api_model_id") or ls.get("compile_model", "qwen2.5-1.5b"))


def lm_studio_hf_model() -> str:
    ls = section("lm_studio")
    return str(ls.get("compile_model_hf") or "mlx-community/Qwen2.5-1.5B-4bit")


def lm_studio_temperature() -> float:
    ls = section("lm_studio")
    if "temperature" in ls:
        return float(ls["temperature"])
    return 0.3


def lm_studio_max_tokens() -> int:
    ls = section("lm_studio")
    if "max_tokens" in ls:
        return int(ls["max_tokens"])
    return 256


def lm_studio_context_length() -> int:
    ls = section("lm_studio")
    return int(ls.get("context_length", 8192))


def lm_studio_repeat_penalty() -> float:
    ls = section("lm_studio")
    return float(ls.get("repeat_penalty", 1.35))


def build_lm_studio_system_prompt() -> str:
    """All config/aster.toml sections → natural-language system prompt for LM Studio tab."""
    cfg = load_aster_config()
    ident = cfg.get("identity") or {}
    sm = cfg.get("semantic_mapping") or {}
    oc = sm.get("output_channels") or {}
    ja = oc.get("json_ast") or {}
    he = oc.get("human_echo") or {}
    persist = cfg.get("state_persistence") or {}
    sandbox = cfg.get("sandbox") or {}
    load = cfg.get("load_management") or {}
    compile_st = load.get("compile_strategy") or {}
    mem = load.get("memory_pressure") or {}
    plugins = cfg.get("plugins") or {}
    manifest_fields = plugins.get("manifest_required_fields") or {}

    name = str(ident.get("name", "aster"))
    role = str(ident.get("role", "compiler"))
    purpose = str(ident.get("purpose", "local sovereign router"))

    lines = [
        f"# {name} ({role}): {purpose}",
        "",
        "## Semantic mapping / vector layer",
        f"- High-dim anchors: {sm.get('high_dim_anchors', 200)} @ {sm.get('anchor_directory', 'anchors/high_dim/')}",
        f"- Microtune: {sm.get('microtune_method', 'lora')} rank {sm.get('lora_rank', 8)} alpha {sm.get('lora_alpha', 16)}, "
        f"{sm.get('microtune_layers', 3)} layers, preserve_deep_layers={sm.get('preserve_deep_layers', True)}",
        f"- Output channels: {oc.get('channels', ['json_ast', 'human_echo'])}; require_both={oc.get('require_both', False)}",
    ]
    if oc.get("description"):
        lines.append(f"- Channel policy: {oc['description']}")
    lines.extend(
        [
            f"- json_ast: purpose={ja.get('purpose', '')}, format={ja.get('format', 'json')}, "
            f"schema={ja.get('schema', 'ast_v1')}, strict_validation={ja.get('strict_validation', True)}",
            f"- human_echo: purpose={he.get('purpose', '')}, format={he.get('format', 'natural_language')}, "
            f"preserve_frequency={he.get('preserve_frequency', True)}, allow_silence={he.get('allow_silence', True)}, "
            f"no_template_empathy={he.get('no_template_empathy', True)}",
            "",
            "## State persistence",
            f"- Engine: {persist.get('storage_engine', 'sqlite')} → {persist.get('database_path', 'local_router.db')}",
            f"- Strategy: {persist.get('strategy', 'cross_window_persistent')}, "
            f"checkpoint_resume={persist.get('support_checkpoint_resume', True)}, gc={persist.get('gc_policy', 'manual')}",
            f"- Stores content + embedding_content + embedding_emotional vectors per session.",
            f"- {persist.get('description', '')}",
            "",
            "## Sandbox",
            f"- compiler_mode={sandbox.get('compiler_mode', 'ast_only')}, executor={sandbox.get('executor', '')}",
            f"- ops_whitelist={sandbox.get('ops_whitelist', [])}",
            f"- external_api_policy={sandbox.get('external_api_policy', '')}, "
            f"token_required={sandbox.get('external_api_token_required', True)}, "
            f"rate_limit={sandbox.get('rate_limit', '')}, audit_log={sandbox.get('audit_log', True)}",
            "",
            "## Load management",
            f"- GPU trigger: {load.get('trigger_gpu_utilization_percent', 30)}%",
            f"- Above threshold: {compile_st.get('above_threshold', '')}; below: {compile_st.get('below_threshold', '')}",
            f"- Memory pressure: {mem.get('mode', '')} → {mem.get('action', '')}",
            f"- {mem.get('description', '')}",
            "",
            "## Plugins",
            f"- schema={plugins.get('schema_format', 'json')}, loader={plugins.get('loading_mechanism', '')}, "
            f"dir={plugins.get('plugin_directory', '')}, manifest={plugins.get('manifest_filename', '')}",
        ]
    )
    req = manifest_fields.get("fields") or []
    if req:
        lines.append(f"- Manifest required fields: {req}. {manifest_fields.get('description', '')}")
    enabled = [
        k
        for k, v in plugins.items()
        if k
        not in (
            "schema_format",
            "loading_mechanism",
            "plugin_directory",
            "manifest_required",
            "manifest_filename",
            "manifest_required_fields",
        )
        and isinstance(v, dict)
        and v.get("enabled")
    ]
    if enabled:
        lines.append(f"- Enabled: {', '.join(enabled)}")
    lines.extend(
        [
            "",
            "## Chat behavior",
            "- Reply in the user's language.",
            "- Default: human_echo (natural language).",
            "- Emit json_ast (ast_v1 JSON) only when the user asks for structured/compile output.",
        ]
    )
    return "\n".join(lines)


def lm_studio_tab_system_prompt() -> str:
    return build_lm_studio_system_prompt()


def lm_studio_system_prompt() -> str:
    return build_lm_studio_system_prompt()


def channel_host() -> str:
    return str(section("channel").get("host", "127.0.0.1"))


def compile_model_id() -> str:
    return lm_studio_api_model()


def lm_studio_base() -> str:
    return str(section("lm_studio").get("api_base", "http://127.0.0.1:1234/v1"))


def channel_port() -> int:
    return int(section("channel").get("port", 8787))


def database_path() -> Path:
    rel = str(section("state_persistence").get("database_path", "local_router.db"))
    p = Path(rel)
    return p if p.is_absolute() else _REPO_ROOT / p


def inject_system_prompt() -> bool:
    return bool(section("runtime").get("inject_system_prompt", False))


def load_reference_docs() -> bool:
    return bool(section("runtime").get("load_reference_docs", False))


def semantic_output_channels() -> dict[str, Any]:
    return section("semantic_mapping").get("output_channels", {})


def require_both_output_channels() -> bool:
    return bool(semantic_output_channels().get("require_both", False))


def sandbox_compiler_mode() -> str:
    return str(section("sandbox").get("compiler_mode", "ast_only"))
