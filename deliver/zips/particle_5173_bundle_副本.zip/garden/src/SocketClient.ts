export type AiStreamSample = { t: number; aiFreq: number; aiAmplitude: number };

const WS_URL = 'ws://localhost:8787/live';

export class SocketClient {
  private ws: WebSocket | null = null;
  private mockTimer: ReturnType<typeof setInterval> | null = null;
  private latest: AiStreamSample = { t: 0, aiFreq: 220, aiAmplitude: 0.15 };
  private onSample: ((s: AiStreamSample) => void) | null = null;

  connect(onSample: (s: AiStreamSample) => void): void {
    this.onSample = onSample;
    this.startMock();
    try {
      const ws = new WebSocket(WS_URL);
      ws.onopen = () => {
        this.stopMock();
        this.ws = ws;
      };
      ws.onmessage = (ev) => {
        try {
          const d = JSON.parse(String(ev.data)) as Partial<AiStreamSample>;
          if (typeof d.t === 'number' && typeof d.aiFreq === 'number' && typeof d.aiAmplitude === 'number') {
            this.latest = { t: d.t, aiFreq: d.aiFreq, aiAmplitude: d.aiAmplitude };
            onSample(this.latest);
          }
        } catch {
          /* ignore malformed */
        }
      };
      ws.onerror = () => {
        if (!this.mockTimer) this.startMock();
      };
      ws.onclose = () => {
        this.ws = null;
        if (!this.mockTimer) this.startMock();
      };
    } catch {
      this.startMock();
    }
  }

  private startMock(): void {
    if (this.mockTimer) return;
    const t0 = performance.now();
    this.mockTimer = setInterval(() => {
      const t = (performance.now() - t0) / 1000;
      const aiFreq = 180 + 90 * Math.sin(t * 0.7) + 40 * Math.sin(t * 2.1);
      const aiAmplitude = 0.12 + 0.08 * Math.sin(t * 1.3) ** 2;
      this.latest = { t, aiFreq, aiAmplitude };
      this.onSample?.(this.latest);
    }, 50);
  }

  private stopMock(): void {
    if (this.mockTimer) {
      clearInterval(this.mockTimer);
      this.mockTimer = null;
    }
  }

  getLatest(): AiStreamSample {
    return this.latest;
  }

  disconnect(): void {
    this.stopMock();
    try {
      this.ws?.close();
    } catch {
      /* ignore */
    }
    this.ws = null;
    this.onSample = null;
  }
}
